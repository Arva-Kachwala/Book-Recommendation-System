from flask import Flask,render_template,request,redirect,url_for
app=Flask(__name__)
fiction=0
romance=0
thriller=0
selfhelp=0
fantasy=0
horror=0
@app.route('/')
def index():
   return render_template('bookrec1.html')
@app.route('/takequiz/Q1',methods=['GET','POST'])
def Q1():
   if request.method == "GET":
    return render_template('quiz1.html')
   else:
    option=request.form["option1"]
    recommend(option)
    return redirect(url_for('Q2'))

@app.route('/takequiz/Q2',methods=['GET','POST'])
def Q2():
   if request.method == "GET":
    return render_template('quiz2.html')
   else:
    option=request.form["option2"]
    recommend(option)
    return redirect(url_for('Q3'))
@app.route('/takequiz/Q3',methods=['GET','POST'])
def Q3():
   if request.method == "GET":
    return render_template('quiz3.html')
   else:
    option=request.form["option3"]
    recommend(option)
    return redirect(url_for('Q4'))
@app.route('/takequiz/Q4',methods=['GET','POST'])
def Q4():
   if request.method == "GET":
    return render_template('quiz4.html')
   else:
    option=request.form["option4"]
    recommend(option)
    return redirect(url_for('Q5'))
@app.route('/takequiz/Q5',methods=['GET','POST'])
def Q5():
   if request.method == "GET":
    return render_template('quiz5.html')
   else:
    option=request.form["option5"]
    recommend(option)
    return redirect(url_for('Q6'))
@app.route('/takequiz/Q6',methods=['GET','POST'])
def Q6():
   if request.method == "GET":
    return render_template('quiz6.html')
   else:
    option=request.form["option6"]
    recommend(option)
    return redirect(url_for('Q7'))
@app.route('/takequiz/Q7',methods=['GET','POST'])
def Q7():
   if request.method == "GET":
    return render_template('quiz7.html')
   else:
    option=request.form["option7"]
    recommend(option)
    return redirect(url_for('Q8'))
@app.route('/takequiz/Q8',methods=['GET','POST'])
def Q8():
   if request.method == "GET":
    return render_template('quiz8.html')
   else:
    option=request.form["option8"]
    recommend(option)
    return redirect(url_for('Q9'))
@app.route('/takequiz/Q9',methods=['GET','POST'])
def Q9():
   if request.method == "GET":
    return render_template('quiz9.html')
   else:
    option=request.form["option9"]
    recommend(option)
    return redirect(url_for('Q10'))
@app.route('/takequiz/Q10',methods=['GET','POST'])
def Q10():
   if request.method == "GET":
    return render_template('quiz10.html')
   else:
    option=request.form["option10"]
    recommend(option)
    return redirect(url_for('recommendation'))
def recommend(option):
   global romance,fiction,thriller,selfhelp,fantasy,horror
   if (option=='1'):
    print("here1")
    romance=romance+1
   elif(option=='2'):
    thriller=thriller+1
   elif(option=='3'):
    fantasy=fantasy+1
   elif(option=='4'):
    selfhelp=selfhelp+1
   elif(option=='5'):
    fiction=fiction+1
    print("here")
   elif(option=='6'):
    horror=horror+1
@app.route('/recommendations',methods=['GET','POST'])
def recommendation():
      global romance,fiction,thriller,selfhelp,fantasy,horror
      list = [romance,fiction,thriller,selfhelp,fantasy,horror]
      maximum=max(list)
      print(list)
      if(maximum==romance):
             return render_template('Romance.html')
      elif(maximum==fiction):
             return render_template('Fiction.html')
      elif(maximum==thriller):
             return render_template('Thriller.html')
      elif(maximum==selfhelp):
             return render_template('Self Help.html')
      elif(maximum==fantasy):
             return render_template('Fantasy.html')
      elif(maximum==horror):
             return render_template('Horror.html')
@app.route('/Homepage',methods=['GET','POST'])
def Homepage():
   return render_template('bookrec1.html')
@app.route('/AboutUs',methods=['GET','POST'])
def AboutUs():
   return render_template('about us.html')
if  __name__=="__main__":
    app.run(debug=True)
